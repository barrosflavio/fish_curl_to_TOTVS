-- Função para executar um comando e capturar sua saída
local function execute_command(command)
    local handle = io.popen(command .. " 2>&1") -- Captura saída de erro também
    local result = handle:read("*a")
    handle:close()
    return result
end

-- Comando a ser executado
local command = "lsb_release -a"

-- Executa o comando e armazena a saída em uma variável
local output = execute_command(command)

-- Procura a linha que contém "Codename"
local codename
for line in output:gmatch("[^\r\n]+") do
    local key, value = line:match("(%S+):%s*(.*)")
    if key == "Codename" then
        codename = value
        break
    end
end

-- Executa comandos diferentes dependendo do Codename
if codename then
    if codename == "xenial" then
        print("Comandos para Ubuntu 16.04")
        -- Verifica a arquitetura
        local arch_command = "uname -m"
        local arch_output = execute_command(arch_command)
        if arch_output:find("i386") then
            print("Executar comandos específicos para arquitetura i386")
            -- Substitua a linha abaixo pelo comando que deseja executar para arquitetura i386 em Ubuntu 16.04
            -- execute_command("seu_comando_para_i386")
        elseif arch_output:find("x86_64") then
            print("Executar comandos específicos para arquitetura x86_64")
            -- Substitua a linha abaixo pelo comando que deseja executar para arquitetura x86_64 em Ubuntu 16.04
            -- execute_command("seu_comando_para_x86_64")
        else
            print("Arquitetura não reconhecida:", arch_output)
        end
    elseif codename == "bionic" then
        print("Comandos para Ubuntu 18.04")
        -- Substitua a linha abaixo pelo comando que deseja executar para o Codename bionic
        -- execute_command("seu_comando_para_bionic")
    else
        print("Codename não reconhecido:", codename)
    end
else
    print("Codename não encontrado.")
end
